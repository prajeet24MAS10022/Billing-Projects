﻿namespace Registration.ViewModel
{
    public class ProductFeature
    {
        public int ProductFeatureID { get; set; }
        public required string ProductFeatureName { get; set; }
        public string ProductVersion { get; set; }
        public required string Discription { get; set; }
        public int ActiveFeature { get; set; }
        public int ProductID { get; set; }

    }
}
