﻿namespace Registration.ViewModel
{
    public class Customer
    {
        public string CustomerID { get; set; }
        public string CompanyName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int ZipCode { get; set; }
        public DateTime OnboardingDate { get; set; }
        public bool Active { get; set; }

        public string AccountPersonName { get; set; }
        public string AccountPersonEmail { get; set; }
        public string AccountPersonContactNo { get; set; }
        public string CRMPersonName { get; set; }
        public string CRMPersonEmail { get; set; }
        public string CRMPersonContactNo { get; set; }
        public string Remarks { get; set; }
        public string ParentCompanyName { get; set; }
        public int ParentCompanyID { get; set; }
    }

    public class CustomerProductlist
    {
        public List<Product> Product { get; set; }
        public List<ProductFeature> ProductFeature { get; set; }
    }
}
