﻿using MySql.Data.MySqlClient;
using Registration.ViewModel;
using System.Data;
namespace Registration.Models
{
    public class DataAccess
    {
        public string InsertData ( Customer objcust )
        {

            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
            {
                string result = "";
                try
                {

                    MySqlCommand mySqlCommand = new MySqlCommand( "InsertCustomerDATA", con );
                    MySqlCommand cmd = mySqlCommand;


                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.AddWithValue("@CustomerID", 0);    
                    cmd.Parameters.AddWithValue( "@CompanyName", objcust.CompanyName );
                    cmd.Parameters.AddWithValue( "@AddressLine1", objcust.AddressLine1 );
                    cmd.Parameters.AddWithValue( "@AddressLine2", objcust.AddressLine2 );
                    cmd.Parameters.AddWithValue( "@State", objcust.State );
                    cmd.Parameters.AddWithValue( "@City", objcust.City );
                    cmd.Parameters.AddWithValue( "@ZipCode", objcust.ZipCode );
                    cmd.Parameters.AddWithValue( "@OnboardingDate", objcust.OnboardingDate );
                    cmd.Parameters.AddWithValue( "@Active ", objcust.Active );
                    cmd.Parameters.AddWithValue( "@ParentCompanyName ", objcust.ParentCompanyName );
                    cmd.Parameters.AddWithValue( "@ParentCompanyID ", objcust.ParentCompanyID );
                    cmd.Parameters.AddWithValue( "@AccountPersonName ", objcust.AccountPersonName );
                    cmd.Parameters.AddWithValue( "@AccountPersonEmail ", objcust.AccountPersonEmail );
                    cmd.Parameters.AddWithValue( "@AccountPersonContactNo ", objcust.AccountPersonContactNo );
                    cmd.Parameters.AddWithValue( "@CRMPersonName", objcust.CRMPersonName );
                    cmd.Parameters.AddWithValue( "@CRMPersonEmail", objcust.CRMPersonEmail );
                    cmd.Parameters.AddWithValue( "@CRMPersonContactNo", objcust.CRMPersonContactNo );
                    cmd.Parameters.AddWithValue( "@Remarks", objcust.Remarks );
                    con.Open();
                    result = cmd.ExecuteScalar().ToString();

                    return result;
                }
                catch
                {
                    return result = "";
                }
                finally
                {
                    con.Close();
                }
            }
        }

        //public string UpdateData ( Customer objcust )
        //{
        //    MySqlConnection con = null;
        //    string result = "";
        //    try
        //    {
        //        con = new MySqlConnection( ConfigurationManager.ConnectionStrings ["DefaultConnection"].ToString() );
        //        MySqlCommand cmd = new MySqlCommand( "InsertCustomerDATA", con );
        //        cmd.Parameters.AddWithValue( "@CompanyName", objcust.CompanyName );
        //        cmd.Parameters.AddWithValue( "@AddressLine1", objcust.AddressLine1 );
        //        cmd.Parameters.AddWithValue( "@AddressLine2", objcust.AddressLine2 );
        //        cmd.Parameters.AddWithValue( "@State", objcust.State );
        //        cmd.Parameters.AddWithValue( "@City", objcust.City );
        //        cmd.Parameters.AddWithValue( "@ZipCode", objcust.ZipCode );
        //        cmd.Parameters.AddWithValue( "@OnboardingDate", objcust.OnboardingDate );
        //        cmd.Parameters.AddWithValue( "@Active ", objcust.Active );
        //        cmd.Parameters.AddWithValue( "@ParentCompanyName ", objcust.ParentCompanyName );
        //        cmd.Parameters.AddWithValue( "@ParentCompanyID ", objcust.ParentCompanyID );
        //        cmd.Parameters.AddWithValue( "@AccountPersonName ", objcust.AccountPersonName );
        //        cmd.Parameters.AddWithValue( "@AccountPersonEmail ", objcust.AccountPersonEmail );
        //        cmd.Parameters.AddWithValue( "@AccountPersonContactNo ", objcust.AccountPersonContactNo );
        //        cmd.Parameters.AddWithValue( "@CRMPersonName", objcust.CRMPersonName );
        //        cmd.Parameters.AddWithValue( "@CRMPersonEmail", objcust.CRMPersonEmail );
        //        cmd.Parameters.AddWithValue( "@CRMPersonContactNo", objcust.CRMPersonContactNo );
        //        cmd.Parameters.AddWithValue( "@Remarks", objcust.Remarks );
        //        con.Open();
        //        result = cmd.ExecuteScalar().ToString();
        //        return result;
        //    }
        //    catch
        //    {
        //        return result = "";
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

    }
}
