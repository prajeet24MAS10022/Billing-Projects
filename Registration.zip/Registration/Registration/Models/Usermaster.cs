﻿namespace Registration.Models
{
    public class Usermaster
    {
        public int UserId { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public int RoleId { get; set; }
        public required string UserName { get; set; }
        public required string Password { get; set; }
        public bool Isactive { get; set; } = true;
    }
}
