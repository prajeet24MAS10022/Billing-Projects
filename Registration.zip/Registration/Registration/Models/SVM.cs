﻿

using Registration.ViewModel;

namespace Registration.Models
{
    public class SVM
    {
        public List<Product> myproducts { get; set; }
        public List<ProductFeature> myproductfeatures { get; set; }

    }
}
