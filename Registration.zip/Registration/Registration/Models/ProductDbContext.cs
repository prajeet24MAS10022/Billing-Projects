﻿using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using Registration.ViewModel;

namespace Registration.Models
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext ( DbContextOptions<ProductDbContext> options ) : base( options )
        {

        }
        public DbSet<Product> Product { get; set; }

        public string ConnectionStrings { get; set; }
        public ProductDbContext ( string connectionStrings )
        {
            this.ConnectionStrings = connectionStrings;
        }
        private MySqlConnection GetConnection ( )
        {
            return new MySqlConnection( ConnectionStrings );
        }

    }
}





