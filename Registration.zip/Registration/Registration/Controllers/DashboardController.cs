﻿
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Registration.ViewModel;

namespace Registration.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index ( )
        {
            return RedirectToAction( "Customer" );
        }
        public IActionResult Price ( )
        {
            return View();
        }

        public IActionResult Projects ( )
        {
            return View();
        }

        public IActionResult Application ( )
        {
            return View();
        }

        public IActionResult Create ( )
        {
            return View();
        }


        public IActionResult Customer ( )
        {
            CustomerProductlist productmodel = new CustomerProductlist();
            productmodel.Product = GetProducts();
            productmodel.ProductFeature = GetProductFeatures();
            return View( productmodel );
        }

        public static List<Product> GetProducts ( )
        {

            List<Product> products = new List<Product>();
            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand( "select * from product", con );
                MySqlDataReader reader1 = cmd.ExecuteReader();

                while (reader1.Read())
                {
                    //extract data
                    Product product = new Product
                    {
                        ProductID = Convert.ToInt32( reader1 ["ProductID"] ),
                        ProductName = reader1 ["ProductName"].ToString(),
                        Discription = reader1 ["Discription"].ToString()
                    };
                    products.Add( product );
                }
                reader1.Close();
            };
            return products;
        }

        public static List<ProductFeature> GetProductFeatures ( )
        {
            List<ProductFeature> productfeatures = new List<ProductFeature>();
            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
            {
                con.Open();
                MySqlCommand cmd1 = new MySqlCommand( "select * from productfeature", con );
                MySqlDataReader reader2 = cmd1.ExecuteReader();

                while (reader2.Read())
                {
                    //extract data

                    ProductFeature productfeature = new ProductFeature
                    {
                        ProductFeatureID = Convert.ToInt32( reader2 ["ProductFeatureID"] ),
                        ProductFeatureName = reader2 ["ProductFeatureName"].ToString(),
                        ProductVersion = Convert.ToString( reader2 ["ProductVersion"] ),
                        Discription = reader2 ["Discription"].ToString(),
                        ActiveFeature = Convert.ToInt32( reader2 ["ActiveFeature"] ),
                        ProductID = Convert.ToInt32( reader2 ["ProductID"] )
                    };
                    productfeatures.Add( productfeature );
                }
                reader2.Close();
            };
            return productfeatures;
        }


    }
}
