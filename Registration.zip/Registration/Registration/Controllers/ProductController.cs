﻿//using Microsoft.AspNetCore.Mvc;
//using MySql.Data.MySqlClient;
//using Registration.Models;
//using System.Collections.Generic;

//namespace Registration.Controllers
//{
//    public class ProductController : Controller
//    {
//        // GET: /<controller>/

//        public List<Product> Putvalue ( )
//        {
//            List<Product> products = new List<Product>();
//            //connection to mysql 
//            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
//            {
//                con.Open();
//                MySqlCommand cmd = new MySqlCommand( "select * from product", con );
//                MySqlDataReader reader1 = cmd.ExecuteReader();

//                while (reader1.Read())
//                {
//                    //extract data
//                    Product product = new Product
//                    {
//                        ProductID = Convert.ToInt32( reader1 ["ProductID"] ),
//                        ProductName = reader1 ["ProductName"].ToString(),
//                        Discription = reader1 ["Discription"].ToString()
//                    };

//                    products.Add( product );
//                }
//                reader1.Close();
//            }
//            ViewBag.model = products;
//            return products;
//        }
//    }
//}


