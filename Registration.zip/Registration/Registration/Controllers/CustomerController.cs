﻿
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Registration.Models;
using Registration.ViewModel;

namespace Registration.Controllers
{
    public class CustomerController : Controller
    {
        public ActionResult Index ( )
        {
            return View();
        }

        public static List<Customer> GetCustomer ( )
        {
            List<Customer> customers = new List<Customer>();
            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
            {
                con.Open();
                MySqlCommand cmd2 = new MySqlCommand( "select * from customer", con );
                MySqlDataReader reader3 = cmd2.ExecuteReader();

                while (reader3.Read())
                {
                    //extract data

                    Customer customer = new Customer
                    {

                        CompanyName = reader3 ["CompanyName"].ToString(),
                        AddressLine1 = Convert.ToString( reader3 ["AddressLine1"] ),
                        AddressLine2 = reader3 ["AddressLine2"].ToString(),
                        State = Convert.ToString( reader3 ["State"] ),
                        City = Convert.ToString( reader3 ["City"] ),
                        ZipCode = Convert.ToInt32( reader3 ["ZipCode"] ),
                        OnboardingDate = Convert.ToDateTime( reader3 ["OnBoardingDate"] ),
                        Active = Convert.ToBoolean( reader3 ["Active"] ),
                        AccountPersonName = reader3 ["AccountPersonName"].ToString(),
                        AccountPersonEmail = reader3 ["AccountPersonEmail"].ToString(),
                        AccountPersonContactNo = reader3 ["AccountPersonContactNo"].ToString(),
                        CRMPersonName = reader3 ["AccountPersonName"].ToString(),
                        CRMPersonEmail = reader3 ["CRMPersonEmail"].ToString(),
                        CRMPersonContactNo = reader3 ["CRMPersonContactNo"].ToString(),
                        Remarks = reader3 ["Remarks"].ToString(),
                        ParentCompanyID = Convert.ToInt32( reader3 ["ParentCompanyID"] ),
                        ParentCompanyName = reader3 ["ParentCompanyName"].ToString()

                    };
                    customers.Add( customer );
                }
                reader3.Close();
            };
            return customers;
        }

        [HttpPost]
        public ActionResult Customer ( Customer objCustomer )
        {

            objCustomer.OnboardingDate = Convert.ToDateTime( objCustomer.OnboardingDate );
            if (ModelState.IsValid) //checking model is valid or not    
            {
                DataAccess objDB = new DataAccess();
                string result = objDB.InsertData( objCustomer );
                //ViewData["result"] = result;    
                TempData ["result1"] = result;
                ModelState.Clear(); //clearing model    
                                    //return View();    
                return RedirectToAction( "Customer" );
            }

            else
            {
                ModelState.AddModelError( "?", "Error in saving data" );
                return View( "Customer" );
            }
        }
        [HttpGet]
        public IActionResult Customer ( )
        {
            Customer objCustomer = new Customer();
            DataAccess objDB = new DataAccess(); //calling class DBdata    
            //objCustomer.ShowallCustomer = objDB.Selectalldata();
            return View( objCustomer );
        }


        //[HttpPost]
        //public ActionResult Edit ( Customer objCustomer )
        //{
        //    objCustomer.OnboardingDate = Convert.ToDateTime( objCustomer.OnboardingDate );
        //    if (ModelState.IsValid) //checking model is valid or not    
        //    {
        //        DataAccess objDB = new DataAccess(); //calling class DBdata    
        //        string result = objDB.UpdateData( objCustomer );
        //        //ViewData["result"] = result;    
        //        TempData ["result2"] = result;
        //        ModelState.Clear(); //clearing model    
        //        //return View();    
        //        return RedirectToAction( "InsertCustomer" );
        //    }
        //    else
        //    {
        //        ModelState.AddModelError( "", "Error in saving data" );
        //        return View();
        //    }
        //}



        //[HttpGet]
        //public ActionResult Edit ( string ID )
        //{
        //    Customer objCustomer = new Customer();
        //    DataAccess objDB = new DataAccess(); //calling class DBdata    
        //    return View( objDB.SelectDatabyID( ID ) );
        //}

        //[HttpPost]
        //public ActionResult Edit ( Customer objCustomer )
        //{
        //    objCustomer. = Convert.ToDateTime( objCustomer. );
        //    if (ModelState.IsValid) //checking model is valid or not    
        //    {
        //        DataAccess objDB = new DataAccess(); //calling class DBdata    
        //        string result = objDB.UpdateData( objCustomer );
        //        //ViewData["result"] = result;    
        //        TempData ["result2"] = result;
        //        ModelState.Clear(); //clearing model    
        //        //return View();    
        //        return RedirectToAction( "ShowAllCustomerDetails" );
        //    }
        //    else
        //    {
        //        ModelState.AddModelError( "", "Error in saving data" );
        //        return View();
        //    }
        //}

    }
}
