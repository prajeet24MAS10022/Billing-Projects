﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Registration.Models;

namespace Registration.Controllers
{
    public class LoginController : Controller
    {
        public List<Usermaster> Putvalue ( )
        {
            List<Usermaster> usermasters = new List<Usermaster>();
            //connection to mysql 
            using (MySqlConnection con = new MySqlConnection( "server=localhost;user=root;database=dbbilling;port=3306;password=admin@123" ))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand( "select * from usermaster", con );
                MySqlDataReader reader1 = cmd.ExecuteReader();

                while (reader1.Read())
                {
                    //extract data
                    Usermaster usermaster = new Usermaster
                    {
                        UserId = Convert.ToInt32( reader1 ["UserId"] ),
                        FirstName = reader1 ["FirstName"].ToString(),
                        LastName = reader1 ["LastName"].ToString(),
                        RoleId = Convert.ToInt32( reader1 ["RoleId"] ),
                        UserName = reader1 ["UserName"].ToString(),
                        Password = reader1 ["Password"].ToString(),
                        Isactive = Convert.ToBoolean( reader1 ["Isactive"] )
                    };

                    usermasters.Add( usermaster );
                }
                reader1.Close();
            }
            return usermasters;
        }
        public IActionResult Verify ( Usermaster usr )
        {
            var u = Putvalue();
            var ue = u.Where( u => u.UserName.Equals( usr.UserName ) );
            var up = ue.Where( p => p.Password.Equals( usr.Password ) );
            if (up.Count() == 1)
            {
                ViewBag.message = "Login success";
                if (ViewBag.isSuccess = true)
                {
                    return RedirectToAction( "Dashboard", "Home" );
                }
                return View();
            }
            else
            {
                ViewBag.message = "Login Fail";
                if (ViewBag.isSuccess = false)
                {
                    return RedirectToAction( "Login", "Home" );
                }
                return View( "Login" );
            }

        }

    }
}
